#ifndef _BMI088_INT_H_
#define _BMI088_INT_H_

#include "sys.h"

void bim088_spi_init(void);

#endif
