#ifndef _BUTTON_H_
#define _BUTTON_H_

#include "sys.h"


void KEY_Init(void);

#endif

