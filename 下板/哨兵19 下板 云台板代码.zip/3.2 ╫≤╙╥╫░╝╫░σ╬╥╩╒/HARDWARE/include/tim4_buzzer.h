#ifndef _TIM4_BUZZER_H_
#define _TIM4_BUZZER_H_

#include "sys.h"


void TIM4_PWM_Init(void);


#endif
