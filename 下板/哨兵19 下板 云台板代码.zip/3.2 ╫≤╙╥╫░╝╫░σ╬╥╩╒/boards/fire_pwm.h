#ifndef _fire_pwm_c
#define _fire_pwm_c

#include "sys.h"

void TIM1_PWM_Init(u32 arr,u32 psc);


#endif

